import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ShoppingBag, Menu, ArrowRight, Coffee, Droplets, Leaf } from 'lucide-react';

const PRODUCTS = [
  {
    id: 1,
    name: "Dark Truffle Mocha",
    price: "$6.50",
    desc: "Double shot espresso pulled over 70% dark artisan chocolate.",
    color: "from-[#3B2016] to-[#1A0E0A]",
    tag: "Bestseller"
  },
  {
    id: 2,
    name: "Caramel Cloud Macchiato",
    price: "$5.80",
    desc: "Vanilla bean, steamed milk, and a rich, buttery caramel drizzle.",
    color: "from-[#D4A373] to-[#BC8A5A]",
    tag: "Sweet"
  },
  {
    id: 3,
    name: "Hazelnut Praline Latte",
    price: "$6.00",
    desc: "Warm roasted hazelnut infused with our signature house blend.",
    color: "from-[#8C6246] to-[#6B4832]",
    tag: "Nutty"
  },
];

const FEATURES = [
  {
    icon: Droplets,
    title: "Velvety Texture",
    desc: "We temper our chocolate to perfectly meld with steamed milk, creating a heavenly mouthfeel."
  },
  {
    icon: Coffee,
    title: "Artisan Roast",
    desc: "Sourced from high-altitude farms for a smooth, acid-free finish that pairs perfectly with cocoa."
  },
  {
    icon: Leaf,
    title: "Organic Cocoa",
    desc: "100% fair-trade, ethically sourced raw cocoa beans from the finest global estates."
  }
];

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#FAF6F0] font-outfit text-[#4A2C2A] selection:bg-[#4A2C2A] selection:text-[#FAF6F0]">
      {/* Navigation */}
      <nav 
        className={`fixed top-0 w-full z-50 transition-all duration-500 px-6 md:px-12 flex justify-between items-center ${
          isScrolled ? 'py-4 bg-[#FAF6F0]/90 backdrop-blur-md shadow-sm' : 'py-8 bg-transparent'
        }`}
      >
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#4A2C2A] rounded-full flex items-center justify-center text-[#FAF6F0]">
            <Coffee size={20} strokeWidth={2.5} />
          </div>
          <span className="font-black text-xl tracking-tight">COFFEE & CO.</span>
        </div>

        <div className="hidden md:flex items-center gap-8 font-semibold text-sm tracking-wide">
          <a href="#" className="hover:text-[#8C6246] transition-colors">MENU</a>
          <a href="#" className="hover:text-[#8C6246] transition-colors">STORY</a>
          <a href="#" className="hover:text-[#8C6246] transition-colors">LOCATIONS</a>
        </div>

        <div className="flex items-center gap-4">
          <button className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center hover:scale-105 transition-transform text-[#4A2C2A]">
            <ShoppingBag size={18} strokeWidth={2.5} />
          </button>
          <button className="md:hidden w-10 h-10 flex items-center justify-center text-[#4A2C2A]">
            <Menu size={24} />
          </button>
        </div>
      </nav>

      {/* Hero Stage (Configured for future 3D Scroll Animation) */}
      <section className="relative h-[200vh] bg-[#FAF6F0]">
        <div className="sticky top-0 h-screen w-full flex flex-col items-center justify-center overflow-hidden">
          
          {/* Ambient sweet backgrounds */}
          <div className="absolute top-1/4 -left-32 md:left-1/4 w-[30rem] h-[30rem] bg-[#D4A373]/15 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute bottom-1/4 -right-32 md:right-1/4 w-[30rem] h-[30rem] bg-[#8C6246]/10 rounded-full blur-[100px] pointer-events-none" />

          {/* Canvas Placeholder for user's 3D product */}
          <div className="absolute inset-0 flex flex-col items-center justify-center z-10 pointer-events-none">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="w-[280px] h-[420px] md:w-[340px] md:h-[500px] border-2 border-dashed border-[#8C6246]/30 rounded-[3rem] flex flex-col items-center justify-center gap-5 bg-white/20 backdrop-blur-sm shadow-[0_0_50px_rgba(140,98,70,0.05)]"
            >
              <Coffee className="w-12 h-12 text-[#8C6246]/40" />
              <p className="text-xs md:text-sm font-bold text-[#8C6246]/60 text-center px-8 uppercase tracking-[0.2em] leading-relaxed">
                Reserved For<br/>3D Scroll Canvas
              </p>
            </motion.div>
          </div>

          {/* Typography Context */}
          <div className="absolute w-full px-6 md:px-16 flex flex-col md:flex-row justify-between items-center md:items-end bottom-12 md:bottom-20 pointer-events-none z-20">
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-[4rem] md:text-[8rem] font-black text-[#4A2C2A] leading-[0.85] tracking-tighter text-center md:text-left mb-6 md:mb-0"
            >
              SWEET &<br/>VELVETY
            </motion.h1>
            
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="max-w-xs text-center md:text-right text-[#8C6246] font-medium text-sm md:text-base"
            >
              <p>Experience the ultimate fusion of rich roasted coffee and premium artisan chocolate.</p>
              <p className="mt-2 text-xs uppercase tracking-widest font-bold text-[#4A2C2A] flex items-center justify-center md:justify-end gap-2">
                Scroll to explore <ArrowRight size={14} />
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section className="py-24 md:py-40 px-6 md:px-12 bg-white relative z-20 rounded-t-[3rem] md:rounded-t-[5rem] shadow-[0_-30px_60px_rgba(74,44,42,0.05)]">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            className="flex flex-col md:flex-row justify-between items-end mb-16 md:mb-24 gap-6"
          >
            <div>
              <h2 className="text-4xl md:text-6xl font-black text-[#4A2C2A] tracking-tight mb-4">Signature Blends</h2>
              <p className="text-[#8C6246] font-medium max-w-md">Crafted with precision, our signature beverages combine the world's finest cocoa with expertly pulled espresso.</p>
            </div>
            <button className="bg-[#FAF6F0] text-[#4A2C2A] px-8 py-4 rounded-full font-bold hover:bg-[#F0E6D8] transition-colors border border-[#4A2C2A]/10 shadow-sm flex items-center gap-2">
              View Full Menu <ArrowRight size={18} />
            </button>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRODUCTS.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: index * 0.15 }}
                whileHover={{ y: -10 }}
                className="bg-[#FAF6F0] rounded-[2.5rem] p-6 flex flex-col gap-6 shadow-sm hover:shadow-[0_20px_40px_rgba(74,44,42,0.08)] transition-all cursor-pointer group"
              >
                <div className={`w-full aspect-[4/5] rounded-[2rem] bg-gradient-to-br ${item.color} relative overflow-hidden flex flex-col items-center justify-center p-6 shadow-inner`}>
                  <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-md px-4 py-1.5 rounded-full text-white text-xs font-bold uppercase tracking-wider">
                    {item.tag}
                  </div>
                  {/* Decorative placeholder inside the card */}
                  <motion.div 
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    <Coffee className="w-24 h-24 text-white/30 drop-shadow-xl" strokeWidth={1} />
                  </motion.div>
                </div>
                
                <div className="px-2">
                  <h3 className="text-2xl font-bold text-[#4A2C2A] mb-2 leading-tight">{item.name}</h3>
                  <p className="text-[#8C6246] text-sm leading-relaxed mb-6 h-12">{item.desc}</p>
                  <div className="flex justify-between items-center pt-4 border-t border-[#4A2C2A]/10">
                    <span className="text-2xl font-black text-[#4A2C2A]">{item.price}</span>
                    <button className="w-12 h-12 rounded-full bg-[#4A2C2A] text-white flex items-center justify-center group-hover:bg-[#8C6246] transition-colors shadow-md">
                      <ShoppingBag className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Crafting Process / Features */}
      <section className="py-24 md:py-32 bg-[#4A2C2A] text-[#FAF6F0] px-6 md:px-12 relative overflow-hidden">
        {/* Subtle decorative background */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#2D1A19] rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16 md:mb-24">
            <h2 className="text-4xl md:text-5xl font-black mb-6">The Sweetest Journey</h2>
            <p className="text-[#D4A373] max-w-2xl mx-auto font-medium leading-relaxed">
              Every cup is a masterpiece. We meticulously source, roast, and craft our ingredients to deliver an unparalleled experience of sweetness and warmth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8">
            {FEATURES.map((feature, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="flex flex-col items-center text-center"
              >
                <div className="w-20 h-20 rounded-2xl bg-[#5C3A21] flex items-center justify-center text-[#D4A373] mb-6 shadow-lg rotate-3 hover:rotate-6 transition-transform">
                  <feature.icon size={36} strokeWidth={1.5} />
                </div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-[#FAF6F0]/70 leading-relaxed max-w-xs">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2D1A19] text-[#FAF6F0]/60 py-12 px-6 md:px-12 text-center text-sm">
        <p>© 2026 Coffee & Co. Crafted with perfection.</p>
      </footer>
    </div>
  );
}
